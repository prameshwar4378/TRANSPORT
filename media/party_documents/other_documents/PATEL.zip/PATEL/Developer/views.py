from django.shortcuts import render,redirect,get_object_or_404
# Create your views here.
from django.contrib.auth import authenticate, login as auth_login, logout as DeleteSession
from django.contrib import messages
from django.contrib.auth.models import User
from . forms import * 

def login(request): 
    if request.user.is_authenticated:
        return redirect_user_based_on_role(request, request.user)

    if request.method == 'POST': 
        username = request.POST.get('username', None)
        password = request.POST.get('password', None)
        user = authenticate(request, username=username, password=password)
        if user is not None:
            auth_login(request, user)
            return redirect_user_based_on_role(request, user)
        else:
            messages.error(request, 'Oops...! User does not exist. Please try again.')

    return render(request, 'login.html')



def update_password(request, id):
    user = get_object_or_404(User, id=id)  # Retrieve the Driver instance safely
    if request.method == 'POST':
        form = UpdatePasswordForm(request.POST)
        if form.is_valid():
            # Set the new password for the user and save
            new_password = form.cleaned_data['new_password1']
            user.set_password(new_password)
            user.save()
            messages.success(request, 'Password updated successfully.')
    else:
        form = UpdatePasswordForm()
    return render(request, 'developer__update_password.html', {'form': form, 'user': user})


def redirect_user_based_on_role(request, user):
    if user.is_superuser or user.is_admin:
        return redirect('/developer/dashboard')
    elif user.is_workshop:
        return redirect('/software/dashboard') 
    else:
        messages.error(request, 'Unauthorized user role.')
        return redirect('login')

def logout(request):
    DeleteSession(request)
    return redirect('/login')
